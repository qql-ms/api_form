# OKX

## OKX: Creating API Keys and connecting to QQL

1. Log in to your account at [OKX](https://www.okx.com)

2. Follow the link to your Account API Management Page [OKX API Management](https://www.okx.com/account/my-api)

3. Click "Create V5 API key"
    ![Create_Key](img/okx/okx_1_create_key.png)

4. Select "API trading", put in an API name (e.g. QQL), create an own "Passphrase" select "Trade", and click "Confirm".

5. Perform the security verification and press "Confirm".

    ![Copy_API](img/okx/okx_3_copy_api.png)

6. Open the QQL API Form page: [QQL API Form](https://qql-api-form.anvil.app/) and log in. At the first usage you need to "Sign up for a new account" and follow the steps. 

    ![API_Form](img/bybit/bybit_4_qql_api_form.png)

7. Enter your name (or alias), select "OKX" as exchange and copy the API Key & Secret Key (as API Secret) from step 5. Enter the Passphrase created in step 4 and finally press "Submit".

    ![API_Form](img/okx/okx_5_qql_api_form_submitted.png)

8. Go back to the OKX API overview from step 5 and click "Confirm".

9. You are all Set and Ready to make Profits with Us!

