# Proof of Reserves (PoR)

## Introduction

If there's one thing we can all agree on, it's that 2022 has been a rough year for everyone in the crypto industry — traders and exchanges alike. Unfortunately, the bearish streak doesn't look to be ending any time soon. Following the FTX saga, which culminated in a bankruptcy announcement on November 11, 2022, proof of reserves, or PoR, has been thrust into the spotlight.

What exactly is PoR, and why does it matter?

### What Is Proof of Reserves (PoR)?

In simple terms, proof of reserves (PoR) refers to a background check (or an independent audit) conducted on crypto exchanges by a third-party auditor. This advanced cryptographic accounting procedure uses a structure called a Merkle Tree, which breaks down complex data into smaller, more digestible chunks for faster and more efficient processing.

The end goal is to ensure that the exchange is financially stable, and carries an amount either equal to or greater than the sum of the clients' balances.

### Why Proof of Reserves Is Important
Ensures 100% Transparency & Protects Client Assets
Laying everything on the table deters a crypto exchange from making secretive financial transactions, such as loaning out more money than the collateral it holds and risking insolvency. In doing so, the clients’ assets are protected as well.

### Helps Exchanges Gain Users' Trust
Proof-of-reserve audits provide an unbiased and completely honest picture of a crypto exchange's funds/financial backing, thereby helping users make more informed decisions. The presence of a PoR reassures users that their money is backed by real assets — while a larger user base translates to greater potential profit, making it a win-win situation.

### The Trigger: FTX's Collapse: What Is FTX, and What Happened?
On November 2, 2022, the balance sheet of one of the biggest exchanges in the world — FTX — was leaked. With it came the revelation that its funds/reserves consisted largely of its native token, FTT. The issue is that FTT is printed directly by FTX and Alameda Research… Meaning the value of the exchange was likely to have been inflated, with many misled into thinking FTX was doing better than it actually was.

Due to unspecified “recent revelations,” Binance CEO Changpeng Zhao said his firm would liquidate its holdings of FTT. A stop was put to FTX withdrawals on November 8, 2022. The same day, Binance offered to buy out FTX, but withdrew its offer the very next day. On November 11, FTX officially announced that it had filed for Chapter 11 bankruptcy in the U.S., with its CEO Sam Bankman-Fried resigning from his position.



Here you can find key statements of the individual exchanges.

## Bybit

Since FTX announced its bankruptcy, the industry has plunged into a state of frenzy. In a bid to soothe frazzled nerves, crypto exchanges worldwide — including Coinbase, Binance and Bybit — have either made their Merkle tree reserve certificates public, or plan to do so in the near future.

In a tweet dated November 9, 2022, Ben Zhou, CEO of Bybit, reassured clients that Bybit has always [been] committed to client fund safety and guarantees 1-to-1 reserves.

Tweet by Bybit CEO Ben Zhou
Source: Ben Zhou on Twitter

### Looking Ahead (2023 and Beyond)

With more crypto exchanges jumping aboard, proof of reserves will hopefully be cemented soon as a standard practice in the industry. In the meantime, if any of your assets are stored directly on crypto exchanges, consider transferring them over to hardware wallets (cold wallets) for additional security.

Overall, proof of reserves is just one criterion with which you can assess the trustworthiness of a crypto platform. As the saying goes, an ounce of prevention is worth a pound of cure. We encourage you to be proactive by reading up on ways in which you can protect your cryptocurrency.

![POR message](img/bybit/bybit_por_twitter_1.png)

For further details visit [Bybit Learn](https://learn.bybit.com/blockchain/what-is-proof-of-reserves-por/).


## OKX (formerly OKEx)

### Introducing OKX Proof of Reserves

Verify your assets with OKX's Proof of Reserves
Our number one priority is to always ensure the safety of our users' funds. But we don't want you to take our word for it. We want you to verify. That's why 
we've recently:

1. Published our on-chain wallet holdings on Nansen, where you can verify that we hold massive reserves of high-quality tokens in cold storage.
2. Published our first Merkle tree Proof of Reserves (PoR) audit, showing we custody our users' funds 1:1.
3. Launched a self-audit feature, making it easy for you to confirm that we hold your assets and to verify our total reserve holdings and reserve ratio.

But that's just the beginning. We're working on a couple more steps:

1. Moving forward, we'll conduct regular audits to update our reserve ratio and the status of your assets.
2. The self-audit feature currently supports Bitcoin (BTC), Ethereum (ETH), and Tether (USDT) – we'll add more assets over time for maximum transparency.

### How to make a self-audit on OKX

You can easily verify we custody your funds 1:1 in a couple of ways:

1. Quick check. To verify if the asset balance of your account has been included as a Merkle leaf, log in to your OKX account, hover over Assets and click Audits. There you'll see our recent audits – click on View details to view the details of your audit's data.
2. Self-audit. You can manually inspect your assets in the Merkle tree by putting our reserves' data structure in the OKX open-source verification tool, MerkleValidator. And if you don't trust our open-source tool, you can even write a similar program for yourself following a few steps!

For further details visit [OKX Learn](https://www.okx.com/learn/proof-of-reserves).
