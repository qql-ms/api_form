 
# Home

## Introduction 
If there's one thing we can all agree on, it's that 2022 has been a rough year for everyone in the crypto industry — traders and exchanges alike. Following the FTX saga, which culminated in a bankruptcy announcement on November 11, 2022, security has been thrust into the spotlight.
As QQL we have been working on to support multiple exchanges in order too avoid any single point of failure and to balance risk. 

So far we support the exchanges Bybit and OKX. 
Bybit does not require any KYC if you are ok to withdraw max. 2 BTC per day. For OKX the KYC process is straight forward.

Support for further exchanges is planned to come in future.
Both exchanges support proof of reserves, or PoR as a security measure.

## Account Opening
If you would like to create an account at one of these exchanges you can do by using the following referral links:

1. [Bybit](https://www.bybit.com/invite?ref=MGRD89)

2. [OKX](https://www.okx.com/join/46123721)

On this site you get further information on the two exchanges and how you can give QQL the required API access.
