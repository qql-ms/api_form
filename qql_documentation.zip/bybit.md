# Bybit

## Bybit: Creating API Keys and connecting to QQL

1. Log in to your account at [Bybit](https://www.bybit.com)

2. Follow the link to your Account API Management Page [Bybit API Management](https://www.bybit.com/app/user/api-management)

3. Click CREATE NEW KEY
    ![Create_Key](img/bybit/bybit_1_create_key.png)

4. Select "API Transaction", put in a name (e.g. QQL), select "Read-Write", and choose "No IP Restriction".

5. In Contracts tick "Orders and Positions"; Tick "Trade" for USDC Contracts, Derivatives API V3, and SPOT. Finally tick "Exchange History" and press "Submit". 

    ![Select API Parameters](img/bybit/bybit_2_api_parameters.png)

6. Perform the security verification to derive to an API overview.

    ![Copy_API](img/bybit/bybit_3_copy_api.png)

7. Open the QQL API Form page: [QQL API Form](https://qql-api-form.anvil.app/) and log in. At the first usage you need to "Sign up for a new account" and follow the steps. 

    ![API_Form](img/bybit/bybit_4_qql_api_form.png)

8. Enter your name (or alias), select the correct exchange and copy the API Key & API Secret from step 6. Finally press "Submit".

    ![API_Form](img/bybit/bybit_5_qql_api_form_submitted.png)

9. Go back to the Bybit API overview from step 6 and click "Understood" on the window with the 2 API Keys and create a reminder on your calendar for the date of expiration (3months from date of creation) of your API Key, so that you can create a new one a few days prior to the expiration.

10. You are all Set and Ready to make Profits with Us!

